package com.company;
import java.awt.*;
import javax.swing.*;

public class Draw extends JPanel{
    private Coordinate c1;
    private Coordinate c2;

    @Override
    public void paintComponent(Graphics graphics){
        super.paintComponents(graphics);

        graphics.setColor(Color.black);
        graphics.drawLine(c1.getX(), c1.getY() , c2.getX() , c2.getY());
    }
}
