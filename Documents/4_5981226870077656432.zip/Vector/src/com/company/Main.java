package com.company;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        Draw draw = new Draw();
        JFrame frame = new JFrame();
        Coordinate c1 = new Coordinate(0 , 0);
        Coordinate c2 = new Coordinate(200 , 200);

        frame.setTitle("vector");
        frame.add(draw);
        frame.setSize(500 , 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
